import java.io.FileNotFoundException;
import java.io.IOException;

public class Driver {
	
	// Declare class data

    public static void main(String[] args) throws FileNotFoundException, IOException {

    	// Read file and call stop detection
    	
    	
    	// Set up frame, include your name in the title
    	
        
        // Set up Panel for input selections
        
    	
        // Play Button
         
    	
        // CheckBox to enable/disable stops
        
    	
        // ComboBox to pick animation time
        
    	
        // Add all to top panel
        
        
        // Set up mapViewer
        
        
        // Add listeners for GUI components
        

        // Set the map center and zoom level
        
        
    }
    
    // Animate the trip based on selections from the GUI components
    
}